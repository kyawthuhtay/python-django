from django.shortcuts import render, redirect

# Create your views here.
from model_form_app import forms
from sample_app import models

def index(request):
	form = forms.EmployeeForm()
	context = {'form': form}
	return render(request, "index_model_form.html", context)

def save(request):
	if request.method == "POST":
		form = forms.EmployeeForm(request.POST, request.FILES)
		if form.is_valid():
			form.save()
			return redirect('/model_form_app/show_model_form/')
		else:
			form = forms.EmployeeForm()
	context = {'form': form}
	return render(request, "index_model_form.html", context)